from tkinter import *

window_width = 400
window_height = 200 

index = 0
photoLabel = None

def onClickNext():
    global index
    global photoLabel
    index += 1
    if index > 12:
        index = 0

    photoFile = str(index) + ".png"
    imageObject = PhotoImage(file=photoFile)

    photoLabel.config(image=imageObject)
    photoLabel.image = imageObject

def main():
    global photoLabel 
    window = Tk()
    window.title("Top Ten Computer Programming Application!")
    window.geometry("300x100")

    photoLabel = Label(window)
    photoLabel.pack(side=TOP)

    #Add a button 
    nextButton = Button(window,text="Next",width=12,command=onClickNext)
    nextButton.pack(side=BOTTOM)

    window.mainloop()

main()
